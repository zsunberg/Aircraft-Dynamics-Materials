function u = quadrotorControls(t, x, xr)
 % state vector: x = [x_E, z_E, uE, wE, theta, q]
    % controls: u = [Zc, Mc]

    g = 9.81;
    m = 2;

    k1 = 0.0067;
    k2 = 0.0768;
    k3 = 0.03*2;
    k4 = 0.1783*2;
    k5 = 4.398;
    k6 = 4.935;
    x
    xr
    dx = x - xr;
    phir = k3*dx(3) + k3*k4*dx(1);
    phir = min(max(phir, -pi/3), pi/3);
    dphi = x(5) - phir;

    Zc = -k5*dx(4) - k6*dx(2) -m*g;
    Mc = -k1*dx(6) - k2*dphi;

    u = [Zc; Mc];
end
